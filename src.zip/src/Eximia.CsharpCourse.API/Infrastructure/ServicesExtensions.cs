﻿using Eximia.CsharpCourse.SeedWork.Settings;

namespace Eximia.CsharpCourse.API.Infrastructure;

internal static class ServicesExtensions
{
    internal static IServiceCollection AddCustomOptions(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<StockApiSettings>(configuration.GetSection("Databricks"));
        return services;
    }
}
