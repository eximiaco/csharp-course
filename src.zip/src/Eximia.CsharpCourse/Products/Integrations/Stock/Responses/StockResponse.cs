﻿namespace Eximia.CsharpCourse.Products.Integrations.Stock.Responses;

public record StockResponse(int ProductId, bool HasStock);
