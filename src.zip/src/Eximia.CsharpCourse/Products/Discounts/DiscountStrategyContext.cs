﻿namespace Eximia.CsharpCourse.Products.Discounts;

public readonly record struct DiscountStrategyContext(int Quantity, DateTime OrderDate);
