﻿namespace Eximia.CsharpCourse.Orders.States;

public interface IOrderState
{
    string Name { get; }
    void Process(Order order);
}
