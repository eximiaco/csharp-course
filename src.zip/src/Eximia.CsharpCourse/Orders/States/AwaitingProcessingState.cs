﻿namespace Eximia.CsharpCourse.Orders.States;

public class AwaitingProcessingState : IOrderState
{
    public string Name => "AwaitingProcessing";

    public void Process(Order order)
    {
        throw new NotImplementedException();
    }
}
