﻿namespace Eximia.CsharpCourse.Orders.IntegrationEvents;

public record OrderCreatedIntegrationEvent(int Id);
