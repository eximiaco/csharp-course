﻿namespace Eximia.CsharpCourse.Orders;

public enum EPaymentMethod
{
    Pix = 1,
    CreditCard = 2
}
