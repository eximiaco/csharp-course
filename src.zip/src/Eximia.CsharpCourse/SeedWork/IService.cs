﻿namespace Eximia.CsharpCourse.SeedWork;

public interface IService<T> { }
