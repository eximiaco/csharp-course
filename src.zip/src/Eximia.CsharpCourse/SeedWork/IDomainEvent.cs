﻿using MediatR;

namespace Eximia.CsharpCourse.SeedWork;

public interface IDomainEvent : INotification { }